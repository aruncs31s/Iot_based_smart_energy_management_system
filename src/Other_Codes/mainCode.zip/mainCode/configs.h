// WARN: Set all Pin Configuration and Setup related to esp32 Here


#define LDR_TOP_RIGHT 13
#define LDR_TOP_LEFT 12
#define LDR_BOTTOM_RIGHT 14
#define LDR_BOTTOM_LEFT 27

#define HORIZONTAL_SERVO 2
#define VERTICAL_SERVO 15
#define SERVO_PIN3 7
#define SERVO_PIN4 8

#define RELAY_PIN1 9
#define RELAY_PIN2 10
#define RELAY_PIN3 11
#define RELAY_PIN4 12

// Setting the LDR resistance Value thresholds
#define LDR_VALUE_HIGH 900;

#define LDR_VALUE_LOW 20;

// Servo Motor Rotation Values
#define SERVO_LIMIT_HIGH 180;
#define SERVO_LIMIT_LOW 10;

